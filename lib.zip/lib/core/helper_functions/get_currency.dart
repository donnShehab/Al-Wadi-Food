// String getCurrency() {
//   return 'USD';
// }
