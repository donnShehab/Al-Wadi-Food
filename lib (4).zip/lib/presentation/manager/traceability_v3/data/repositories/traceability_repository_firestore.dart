import 'package:alwadi_food/presentation/manager/traceability_v3/domain/models/recall_audit_model.dart';
import 'package:alwadi_food/presentation/manager/traceability_v3/domain/models/trace_edge_model.dart';
import 'package:alwadi_food/presentation/manager/traceability_v3/domain/models/trace_graph_model.dart';
import 'package:alwadi_food/presentation/manager/traceability_v3/domain/models/trace_node_model.dart';
import 'package:alwadi_food/presentation/manager/traceability_v3/domain/repositories/traceability_repository.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

/// ============================================================
/// 🔥 Firestore Implementation — Traceability V3
/// ============================================================

class TraceabilityV3RepositoryFirestore implements TraceabilityV3Repository {
  final FirebaseFirestore firestore;

  TraceabilityV3RepositoryFirestore(this.firestore);

  // ============================================================
  // 🔹 LOAD TRACEABILITY GRAPH
  // ============================================================

  @override
  Future<TraceGraphModel> loadGraph({required String rootNodeId}) async {
    /// 1️⃣ Fetch all nodes connected to root
    final nodesSnapshot = await firestore.collection('trace_nodes').get();

    /// 2️⃣ Fetch all edges
    final edgesSnapshot = await firestore.collection('trace_edges').get();

    final nodes = <String, TraceNodeModel>{};
    final edges = <TraceEdgeModel>[];

    for (final doc in nodesSnapshot.docs) {
      final data = doc.data();
      final node = TraceNodeModel(
        id: doc.id,
        type: data['type'],
        label: data['label'],
        status: data['status'],
        createdAt:
            (data['createdAt'] as Timestamp?)?.toDate() ??
            DateTime.fromMillisecondsSinceEpoch(0),
      );

      nodes[node.id] = node;
    }

    for (final doc in edgesSnapshot.docs) {
      final data = doc.data();
      edges.add(TraceEdgeModel(from: data['from'], to: data['to']));
    }

    /// 3️⃣ Build graph
    return TraceGraphModel(rootNodeId: rootNodeId, nodes: nodes, edges: edges);
  }

  // ============================================================
  // 🔹 UPDATE NODE STATUSES (ATOMIC)
  // ============================================================

  @override
  Future<void> updateNodeStatuses({
    required Map<String, String> statusUpdates,
  }) async {
    final batch = firestore.batch();

    for (final entry in statusUpdates.entries) {
      final ref = firestore.collection('trace_nodes').doc(entry.key);

      batch.update(ref, {
        'status': entry.value,
        'updatedAt': FieldValue.serverTimestamp(),
      });
    }

    await batch.commit();
  }

  // ============================================================
  // 🔹 CREATE RECALL AUDIT
  // ============================================================

  @override
  Future<void> createRecallAudit({
    required Map<String, dynamic> auditPayload,
  }) async {
    await firestore.collection('trace_audits').add({
      ...auditPayload,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  // ============================================================
  // 🔹 FETCH RECALL AUDITS
  // ============================================================

  @override
  Future<List<Map<String, dynamic>>> fetchRecallAudits({int limit = 50}) async {
    final snapshot = await firestore
        .collection('trace_audits')
        .orderBy('createdAt', descending: true)
        .limit(limit)
        .get();

    return snapshot.docs.map((d) => d.data()).toList();
  }

  @override
  Future<void> executeRecall({
    required Map<String, String> statusUpdates,
    required RecallAuditModel audit,
  }) async {
    final batch = firestore.batch();

    /// 1️⃣ Update affected nodes
    for (final entry in statusUpdates.entries) {
      final ref = firestore.collection('trace_nodes').doc(entry.key);

      batch.update(ref, {
        'status': entry.value,
        'updatedAt': FieldValue.serverTimestamp(),
      });
    }

    /// 2️⃣ Create audit log
    final auditRef = firestore.collection('trace_audits').doc();
    batch.set(auditRef, {
      ...audit.toFirestore(),
      'createdAt': FieldValue.serverTimestamp(),
    });

    /// 3️⃣ Commit atomically
    await batch.commit();
  }
}
