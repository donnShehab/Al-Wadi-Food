// presentation/views/traceability_view_body.dart

import 'package:flutter/material.dart';

import '../../domain/models/recall_result_model.dart';
import '../../domain/services/recall_severity_service.dart';
import '../cubit/traceability_state.dart';
import '../projections/recall_severity_ui_model.dart';
import '../widgets/recall_empty_state.dart';
import '../widgets/recall_radar.dart';
import '../widgets/recall_timeline.dart';

class TraceabilityViewBody extends StatelessWidget {
  final TraceabilityState state;
  final String rootNodeId;

  /// 🔑 NEW: callback injected from TraceabilityView
  final void Function(RecallResultModel recallResult) onConfirmRecall;

  const TraceabilityViewBody({
    super.key,
    required this.state,
    required this.rootNodeId,
    required this.onConfirmRecall,
  });

  @override
  Widget build(BuildContext context) {
    if (state is TraceabilityLoading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (state is TraceabilityRecallReady) {
      final recallState = state as TraceabilityRecallReady;
      final domainResult = recallState.projection.domainResult;

      /// 🔥 Severity (domain-backed)
      final severity = RecallSeverityService.evaluate(domainResult);
      final severityUi = RecallSeverityUiModel.fromSeverity(severity);

      return Column(
        children: [
          // ============================================================
          // 🚨 SEVERITY HEADER
          // ============================================================
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            margin: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: severityUi.color.withOpacity(0.15),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              children: [
                Icon(Icons.warning, color: severityUi.color),
                const SizedBox(width: 8),
                Text(
                  severityUi.label,
                  style: TextStyle(
                    color: severityUi.color,
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
                const Spacer(),
                Text(
                  '${domainResult.affectedNodes.length} nodes affected',
                  style: const TextStyle(fontSize: 14),
                ),
              ],
            ),
          ),

          // ============================================================
          // 📡 VISUALIZATIONS
          // ============================================================
          Expanded(
            flex: 2,
            child: RecallRadar(projection: recallState.projection),
          ),
          Expanded(
            flex: 3,
            child: RecallTimeline(projection: recallState.projection),
          ),

          // ============================================================
          // 🔐 ACTION PANEL — CONFIRMATION
          // ============================================================
          Padding(
            padding: const EdgeInsets.all(16),
            child: SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: severityUi.color,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
                onPressed: () {
                  showDialog(
                    context: context,
                    builder: (_) => AlertDialog(
                      title: const Text('Confirm Recall Execution'),
                      content: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            severityUi.label,
                            style: TextStyle(
                              color: severityUi.color,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 12),
                          Text(
                            'Affected Nodes: ${domainResult.affectedNodes.length}',
                          ),
                          Text(
                            'Maximum Trace Depth: ${domainResult.maxDepth}',
                          ),
                          const SizedBox(height: 16),
                          const Text(
                            'This action will BLOCK all affected nodes '
                            'and create an immutable audit record.\n\n'
                            'Do you want to proceed?',
                          ),
                        ],
                      ),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: const Text('Cancel'),
                        ),
                        ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: severityUi.color,
                          ),
                          onPressed: () {
                            Navigator.pop(context);

                            /// 🔥 Delegate execution to View
                            onConfirmRecall(domainResult);
                          },
                          child: const Text('Confirm & Execute'),
                        ),
                      ],
                    ),
                  );
                },
                child: const Text(
                  'Execute Recall',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ),
        ],
      );
    }

    return const RecallEmptyState();
  }
}
