import 'dart:ui';

import 'package:alwadi_food/presentation/qc/presentation/views/qc_analytics_view.dart';
import 'package:alwadi_food/presentation/qc/presentation/views/qc_insights_view.dart';
import 'package:alwadi_food/presentation/qc/presentation/views/qc_reports_view.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'package:alwadi_food/presentation/qc/cubit/qc_cubit.dart';
import 'package:alwadi_food/presentation/qc/cubit/qc_state.dart';

import 'widgets/qc_dashboard/qc_dashboard_body.dart';

class QCCommandCenterView extends StatefulWidget {
  const QCCommandCenterView({super.key});

  @override
  State<QCCommandCenterView> createState() => _QCCommandCenterViewState();
}

class _QCCommandCenterViewState extends State<QCCommandCenterView> {
  int _index = 0;

  @override
  void initState() {
    super.initState();
    context.read<QCCubit>().loadQCDashboard(); // ✅ KEEP EXACT
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      // ✅ UI-only: executive background (instead of flat color)
      body: DecoratedBox(
        decoration: BoxDecoration(
          gradient: RadialGradient(
            center: Alignment.topCenter,
            radius: 1.35,
            colors: [
              theme.colorScheme.surface,
              theme.colorScheme.primary.withOpacity(0.035),
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // ✅ AppBar (same title) لكن بطريقة “executive”
              _ExecutiveTopBar(
                title: "QC Command Center",
                onBack: () => Navigator.maybePop(context),
              ),

              // ✅ Body as-is (BlocBuilder logic unchanged)
              Expanded(
                child: BlocBuilder<QCCubit, QCState>(
                  builder: (context, state) {
                    if (state is QCLoading) {
                      return const Center(child: CircularProgressIndicator());
                    }

                    if (state is QCError) {
                      return Center(
                        child: Text(
                          state.message,
                          style: const TextStyle(color: Colors.red),
                        ),
                      );
                    }

                    if (state is QCDashboardLoaded) {
                      final pages = [
                        QCDashboardBody(
                          pendingCount: state.pendingCount,
                          passedToday: state.passedToday,
                          failedToday: state.failedToday,
                          recentResults: state.recentResults,
                          riskLevel: state.riskLevel,
                          alerts: state.alerts,
                          trend: state.trend,
                          recommendations: state.recommendations,
                        ),
                        QCAnalyticsView(),
                        QCInsightsView(),
                        const QCReportsView(),
                      ];

                      return AnimatedSwitcher(
                        duration: const Duration(milliseconds: 250),
                        child: pages[_index],
                      );
                    }

                    return const SizedBox();
                  },
                ),
              ),

              // ✅ Bottom Navigation (premium glass / pill highlight)
              _ExecutiveNavBar(
                selectedIndex: _index,
                onDestinationSelected: (value) {
                  setState(() => _index = value); // ✅ KEEP EXACT behavior
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// ===========================
///  Executive Top Bar (UI only)
/// ===========================
class _ExecutiveTopBar extends StatelessWidget {
  const _ExecutiveTopBar({required this.title, required this.onBack});

  final String title;
  final VoidCallback onBack;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: theme.colorScheme.primary,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.10),
            blurRadius: 18,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Row(
        children: [
          IconButton(
            onPressed: onBack,
            icon: const Icon(Icons.arrow_back),
            color: Colors.white,
          ),
          Expanded(
            child: Text(
              title,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontWeight: FontWeight.w800,
                color: Colors.white,
                fontSize: 18,
                letterSpacing: -0.2,
              ),
            ),
          ),
          const SizedBox(width: 48), // balance for centered title
        ],
      ),
    );
  }
}

/// ===========================
///  Executive Nav Bar (UI only)
/// ===========================
class _ExecutiveNavBar extends StatelessWidget {
  const _ExecutiveNavBar({
    required this.selectedIndex,
    required this.onDestinationSelected,
  });

  final int selectedIndex;
  final ValueChanged<int> onDestinationSelected;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return ClipRRect(
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
        child: Container(
          padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.82),
            border: Border(
              top: BorderSide(
                color: theme.colorScheme.onSurface.withOpacity(0.08),
              ),
            ),
          ),
          child: NavigationBar(
            selectedIndex: selectedIndex,
            height: 64,
            backgroundColor: Colors.transparent,
            elevation: 0,
            indicatorColor: theme.colorScheme.primary.withOpacity(0.12),
            onDestinationSelected: onDestinationSelected,
            destinations: const [
              NavigationDestination(
                icon: Icon(Icons.dashboard_outlined),
                selectedIcon: Icon(Icons.dashboard),
                label: "Overview",
              ),
              NavigationDestination(
                icon: Icon(Icons.show_chart_outlined),
                selectedIcon: Icon(Icons.show_chart),
                label: "Analytics",
              ),
              NavigationDestination(
                icon: Icon(Icons.lightbulb_outline),
                selectedIcon: Icon(Icons.lightbulb),
                label: "Insights",
              ),
              NavigationDestination(
                icon: Icon(Icons.picture_as_pdf_outlined),
                selectedIcon: Icon(Icons.picture_as_pdf),
                label: "Reports",
              ),
            ],
          ),
        ),
      ),
    );
  }
}
