import '../entities/trace_dashboard_entity.dart';
import '../entities/trace_search_result_entity.dart';
import '../entities/trace_batch_entity.dart';
import '../entities/trace_event_entity.dart';
import '../entities/trace_qc_result_entity.dart';

abstract class TraceabilityRepository {
  Future<List<TraceSearchResultEntity>> searchBatches({
    required String query,
    String status,
    String line,
    int limit,
  });

  /// Realtime streams
  Stream<TraceBatchEntity?> watchBatchByDocId(String docId);

  Stream<List<TraceEventEntity>> watchTraceEventsByBatchId(String batchId);

  Stream<List<TraceQcResultEntity>> watchQcResultsByBatchId(String batchId);

  Future<TraceDashboardEntity> loadDashboardKpis({int limit});
}
