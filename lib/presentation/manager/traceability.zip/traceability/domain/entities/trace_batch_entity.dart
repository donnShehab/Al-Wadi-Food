import 'package:equatable/equatable.dart';

class TraceBatchEntity extends Equatable {
  final String docId; // Firestore doc.id
  final String batchId; // internal batch code (field batchId)

  final String product;
  final String line;
  final int quantity;
  final DateTime createdAt;
  final String status;

  final String createdBy; // userId
  final List<String> images;

  const TraceBatchEntity({
    required this.docId,
    required this.batchId,
    required this.product,
    required this.line,
    required this.quantity,
    required this.createdAt,
    required this.status,
    required this.createdBy,
    required this.images,
  });

  @override
  List<Object?> get props => [
    docId,
    batchId,
    product,
    line,
    quantity,
    createdAt,
    status,
    createdBy,
    images,
  ];
}
