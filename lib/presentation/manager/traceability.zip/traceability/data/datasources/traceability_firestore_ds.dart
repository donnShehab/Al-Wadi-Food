import 'package:alwadi_food/core/constants/app_constants.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class TraceabilityFirestoreDataSource {
  final FirebaseFirestore firestore;

  TraceabilityFirestoreDataSource(this.firestore);

  Future<QuerySnapshot<Map<String, dynamic>>> fetchLatestBatches({
    int limit = 80,
  }) async {
    try {
      return await firestore
          .collection(AppConstants.batchesCollection)
          .orderBy('createdAt', descending: true)
          .limit(limit)
          .get();
    } catch (e) {
      // ignore: avoid_print
      print("[TraceabilityDS] fetchLatestBatches ERROR: $e");
      rethrow;
    }
  }


  Stream<DocumentSnapshot<Map<String, dynamic>>> watchBatchDoc(String docId) {
    return firestore
        .collection(AppConstants.batchesCollection)
        .doc(docId)
        .snapshots();
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> watchTraceEvents(String batchId) {
    return firestore
        .collection(AppConstants.traceEventsCollection)
        .where('batchId', isEqualTo: batchId)
        .orderBy('timestamp', descending: false)
        .snapshots();
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> watchQcResults(String batchId) {
    return firestore
        .collection(AppConstants.qcResultsCollection)
        .where('batchId', isEqualTo: batchId)
        .orderBy('createdAt', descending: true)
        .snapshots();
  }

  Future<QuerySnapshot<Map<String, dynamic>>> fetchLatestTraceEvents({
    int limit = 50,
  }) {
    return firestore
        .collection(AppConstants.traceEventsCollection)
        .orderBy('timestamp', descending: true)
        .limit(limit)
        .get();
  }
}
