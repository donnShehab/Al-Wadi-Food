import 'package:alwadi_food/core/constants/app_constants.dart';
import '../../domain/entities/trace_batch_entity.dart';
import '../../domain/entities/trace_dashboard_entity.dart';
import '../../domain/entities/trace_event_entity.dart';
import '../../domain/entities/trace_qc_result_entity.dart';
import '../../domain/entities/trace_search_result_entity.dart';
import '../../domain/repos/traceability_repository.dart';
import '../datasources/traceability_firestore_ds.dart';
import '../mappers/traceability_firestore_mapper.dart';

class TraceabilityRepositoryImpl implements TraceabilityRepository {
  final TraceabilityFirestoreDataSource ds;

  TraceabilityRepositoryImpl({required this.ds});

  @override
  Future<List<TraceSearchResultEntity>> searchBatches({
    required String query,
    String status = 'All',
    String line = 'All',
    int limit = 80,
  }) async {
    final snap = await ds.fetchLatestBatches(limit: limit);
    final all = snap.docs.map(TraceabilityFirestoreMapper.mapSearchResult);

    final q = query.trim().toLowerCase();

    return all.where((r) {
      final matchesQuery = q.isEmpty
          ? true
          : r.batchCode.toLowerCase().contains(q) ||
                r.docId.toLowerCase().contains(q) ||
                r.product.toLowerCase().contains(q) ||
                r.line.toLowerCase().contains(q);

      final matchesStatus = status == 'All'
          ? true
          : r.status.toLowerCase() == status.toLowerCase();

      final matchesLine = line == 'All'
          ? true
          : r.line.toLowerCase() == line.toLowerCase();

      return matchesQuery && matchesStatus && matchesLine;
    }).toList();
  }

  @override
  Stream<TraceBatchEntity?> watchBatchByDocId(String docId) {
    return ds.watchBatchDoc(docId).map(TraceabilityFirestoreMapper.mapBatchDoc);
  }

  @override
  Stream<List<TraceEventEntity>> watchTraceEventsByBatchId(String batchId) {
    return ds.watchTraceEvents(batchId).map((snap) {
      final list = snap.docs
          .map(TraceabilityFirestoreMapper.mapTraceEvent)
          .toList();
      list.sort((a, b) => a.timestamp.compareTo(b.timestamp));
      return list;
    });
  }

  @override
  Stream<List<TraceQcResultEntity>> watchQcResultsByBatchId(String batchId) {
    return ds.watchQcResults(batchId).map((snap) {
      return snap.docs.map(TraceabilityFirestoreMapper.mapQcResult).toList();
    });
  }

  @override
  Future<TraceDashboardEntity> loadDashboardKpis({int limit = 140}) async {
    final snap = await ds.fetchLatestBatches(limit: limit);

    int passed = 0;
    int failed = 0;
    int waiting = 0;

    for (final d in snap.docs) {
      final status = (d.data()['status'] ?? 'unknown').toString();
      if (status == AppConstants.statusPassed) passed++;
      if (status == AppConstants.statusFailed) failed++;
      if (status == AppConstants.statusWaitingQC) waiting++;
    }

    final total = snap.docs.length;
    final denom = (passed + failed);
    final passRate = denom == 0 ? 0.0 : (passed / denom) * 100.0;

    final eventsSnap = await ds.fetchLatestTraceEvents(limit: 50);
    final alerts = <String>[];

    for (final e in eventsSnap.docs) {
      final type = (e.data()['type'] ?? '').toString();
      if (type == 'QC_FAILED' || type == 'REJECTED') {
        final title = (e.data()['title'] ?? 'Alert').toString();
        alerts.add(title);
      }
      if (alerts.length >= 6) break;
    }

    return TraceDashboardEntity(
      totalBatches: total,
      passedCount: passed,
      failedCount: failed,
      waitingQcCount: waiting,
      passRate: passRate,
      latestAlerts: alerts,
    );
  }
}
