import 'dart:async';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../domain/entities/trace_batch_entity.dart';
import '../domain/entities/trace_bundle_entity.dart';
import '../domain/entities/trace_event_entity.dart';
import '../domain/entities/trace_qc_result_entity.dart';
import '../domain/repos/traceability_repository.dart';
import 'traceability_state.dart';

class TraceabilityCubit extends Cubit<TraceabilityState> {
  final TraceabilityRepository repo;

  TraceabilityCubit(this.repo) : super(TraceabilityState.initial());

  StreamSubscription<TraceBatchEntity?>? _batchSub;
  StreamSubscription<List<TraceEventEntity>>? _eventsSub;
  StreamSubscription<List<TraceQcResultEntity>>? _qcSub;

  TraceBatchEntity? _latestBatch;
  List<TraceEventEntity> _latestEvents = const [];
  List<TraceQcResultEntity> _latestQc = const [];

  void updateQuery(String v) => emit(state.copyWith(query: v));
  void updateStatusFilter(String v) => emit(state.copyWith(statusFilter: v));
  void updateLineFilter(String v) => emit(state.copyWith(lineFilter: v));

  Future<void> init() async {
    await Future.wait([search(), loadDashboard()]);
  }

  Future<void> search() async {
    // Prevent re-entrant searches (optional but helpful)
    if (state.status == TraceabilityViewStatus.searching) return;

    try {
      emit(
        state.copyWith(status: TraceabilityViewStatus.searching, error: null),
      );

      // ✅ Debug start
      // ignore: avoid_print
      print(
        "[Traceability] search() START | q='${state.query}' status='${state.statusFilter}' line='${state.lineFilter}'",
      );

      // ✅ Timeout prevents infinite loading forever
      final results = await repo
          .searchBatches(
            query: state.query,
            status: state.statusFilter,
            line: state.lineFilter,
            limit: 100,
          )
          .timeout(
            const Duration(seconds: 12),
            onTimeout: () {
              throw Exception(
                "Search timeout. Firestore request took too long. Check network / Firestore rules / indexes.",
              );
            },
          );

      // ✅ Debug success
      // ignore: avoid_print
      print("[Traceability] search() SUCCESS | results=${results.length}");

      emit(
        state.copyWith(
          status: TraceabilityViewStatus.loaded,
          results: results,
          error: null,
        ),
      );
    } catch (e, st) {
      // ✅ Debug error (very important)
      // ignore: avoid_print
      print("[Traceability] search() ERROR: $e");
      // ignore: avoid_print
      print(st);

      emit(
        state.copyWith(
          status: TraceabilityViewStatus.error,
          error: e.toString(),
          results: const [],
        ),
      );
    }
  }



  /// ✅ Core fix: when tapped, set selectedDocId + start realtime bundle subscriptions
  Future<void> openBatch(String docId) async {
    await _cancelSubs();

    _latestBatch = null;
    _latestEvents = const [];
    _latestQc = const [];

    emit(state.copyWith(
      status: TraceabilityViewStatus.loadingBundle,
      selectedDocId: docId,
      selectedBundle: null,
      error: null,
    ));

    // 1) Watch batch doc by docId
    _batchSub = repo.watchBatchByDocId(docId).listen((batch) {
      _latestBatch = batch;
      _rebuildBundle();
    }, onError: (e) {
      emit(state.copyWith(status: TraceabilityViewStatus.error, error: e.toString()));
    });
  }

  void _attachStreamsUsingBatchId(String batchId) {
    // 2) Trace events by batchId (link id)
    _eventsSub = repo.watchTraceEventsByBatchId(batchId).listen((events) {
      _latestEvents = events;
      _rebuildBundle();
    }, onError: (e) {
      emit(state.copyWith(status: TraceabilityViewStatus.error, error: e.toString()));
    });

    // 3) QC results by batchId (link id)
    _qcSub = repo.watchQcResultsByBatchId(batchId).listen((qc) {
      _latestQc = qc;
      _rebuildBundle();
    }, onError: (e) {
      emit(state.copyWith(status: TraceabilityViewStatus.error, error: e.toString()));
    });
  }

  void _rebuildBundle() {
    final batch = _latestBatch;

    if (batch == null) {
      // still loading or doc missing
      // if doc missing → show error to manager clearly
      emit(state.copyWith(
        status: TraceabilityViewStatus.error,
        error: "Batch not found (doc missing). Check document ID.",
      ));
      return;
    }

    // Attach downstream streams once (after we have a batchId)
    // We only do this the first time.
    if (_eventsSub == null && _qcSub == null) {
      _attachStreamsUsingBatchId(batch.batchId);
    }

    final bundle = TraceBundleEntity(
      batch: batch,
      events: _latestEvents,
      qcResults: _latestQc,
    );

    emit(state.copyWith(
      status: TraceabilityViewStatus.loaded,
      selectedBundle: bundle,
      error: null,
    ));
  }

  void clearSelected() {
    _cancelSubs();
    emit(state.copyWith(clearSelected: true, status: TraceabilityViewStatus.loaded));
  }

  Future<void> loadDashboard() async {
    try {
      final dash = await repo.loadDashboardKpis(limit: 160);
      emit(state.copyWith(dashboard: dash));
    } catch (_) {
      // keep dashboard optional
    }
  }

  Future<void> _cancelSubs() async {
    await _batchSub?.cancel();
    await _eventsSub?.cancel();
    await _qcSub?.cancel();

    _batchSub = null;
    _eventsSub = null;
    _qcSub = null;
  }

  @override
  Future<void> close() async {
    await _cancelSubs();
    return super.close();
  }
}
