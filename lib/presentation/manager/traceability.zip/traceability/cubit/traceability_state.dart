import 'package:equatable/equatable.dart';
import '../domain/entities/trace_bundle_entity.dart';
import '../domain/entities/trace_dashboard_entity.dart';
import '../domain/entities/trace_search_result_entity.dart';

enum TraceabilityViewStatus { idle, searching, loadingBundle, loaded, error }

class TraceabilityState extends Equatable {
  final TraceabilityViewStatus status;

  final String query;
  final String statusFilter;
  final String lineFilter;

  final List<TraceSearchResultEntity> results;

  /// ✅ Selected batch doc id (for loading batch doc)
  final String? selectedDocId;

  /// ✅ Selected bundle (batch + events + qc)
  final TraceBundleEntity? selectedBundle;

  final TraceDashboardEntity dashboard;
  final String? error;

  const TraceabilityState({
    required this.status,
    required this.query,
    required this.statusFilter,
    required this.lineFilter,
    required this.results,
    required this.selectedDocId,
    required this.selectedBundle,
    required this.dashboard,
    required this.error,
  });

  factory TraceabilityState.initial() => TraceabilityState(
    status: TraceabilityViewStatus.idle,
    query: '',
    statusFilter: 'All',
    lineFilter: 'All',
    results: const [],
    selectedDocId: null,
    selectedBundle: null,
    dashboard: TraceDashboardEntity.empty(),
    error: null,
  );

  TraceabilityState copyWith({
    TraceabilityViewStatus? status,
    String? query,
    String? statusFilter,
    String? lineFilter,
    List<TraceSearchResultEntity>? results,
    String? selectedDocId,
    TraceBundleEntity? selectedBundle,
    TraceDashboardEntity? dashboard,
    String? error,
    bool clearSelected = false,
  }) {
    return TraceabilityState(
      status: status ?? this.status,
      query: query ?? this.query,
      statusFilter: statusFilter ?? this.statusFilter,
      lineFilter: lineFilter ?? this.lineFilter,
      results: results ?? this.results,
      selectedDocId: clearSelected
          ? null
          : (selectedDocId ?? this.selectedDocId),
      selectedBundle: clearSelected
          ? null
          : (selectedBundle ?? this.selectedBundle),
      dashboard: dashboard ?? this.dashboard,
      error: error,
    );
  }

  @override
  List<Object?> get props => [
    status,
    query,
    statusFilter,
    lineFilter,
    results,
    selectedDocId,
    selectedBundle,
    dashboard,
    error,
  ];
}
