import 'package:alwadi_food/core/router/app_router.dart';
import 'package:alwadi_food/core/utils/date_formatter.dart';
import 'package:alwadi_food/presentation/manager/cubit/manager_dashboard/manager_dashboard_cubit.dart';
import 'package:alwadi_food/presentation/manager/cubit/manager_dashboard/manager_dashboard_state.dart';
import 'package:alwadi_food/presentation/manager/cubit/manager_nav/manager_nav_cubit.dart';
import 'package:alwadi_food/presentation/manager/traceability/presentation/widgets/manager_dashboard/executive_control_metrics_service.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';

class ManagerDashboardViewBodyBlocConsumer extends StatefulWidget {
  final ThemeData theme;

  const ManagerDashboardViewBodyBlocConsumer({super.key, required this.theme});

  @override
  State<ManagerDashboardViewBodyBlocConsumer> createState() =>
      _ManagerDashboardViewBodyBlocConsumerState();
}

class _ManagerDashboardViewBodyBlocConsumerState
    extends State<ManagerDashboardViewBodyBlocConsumer> {
  late Future<ExecutiveControlMetrics> _metricsFuture;

  @override
  void initState() {
    super.initState();
    _metricsFuture = ExecutiveControlMetricsService().fetch();
  }

  void _refresh() {
    context.read<ManagerDashboardCubit>().loadDashboard();
    setState(() {
      _metricsFuture = ExecutiveControlMetricsService().fetch();
    });
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<ManagerDashboardCubit, ManagerDashboardState>(
      listener: (context, state) {
        if (state is ManagerDashboardError) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(state.message),
              backgroundColor: widget.theme.colorScheme.error,
            ),
          );
        }
      },
      builder: (context, state) {
        if (state is ManagerDashboardLoading || state is ManagerDashboardInitial) {
          return _ExecutiveControlLoading(onRefresh: _refresh);
        }

        if (state is ManagerDashboardLoaded) {
          final data = state.data;

          return Scaffold(
            backgroundColor: const Color(0xFFF7F9FC),
            body: SafeArea(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    FutureBuilder<ExecutiveControlMetrics>(
                      future: _metricsFuture,
                      builder: (context, snapshot) {
                        final waiting =
                            snapshot.connectionState == ConnectionState.waiting;

                        final metrics = snapshot.data;
                        final badge =
                            metrics == null ? null : _statusBadgeFrom(metrics);

                        // 1) Executive Header
                        final header = _ExecutiveHeader(
                          managerName: data.managerName,
                          role: data.managerRole,
                          date: data.today,
                          onRefresh: _refresh,
                          badge: badge,
                        );

                        if (snapshot.hasError) {
                          return Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              header,
                              const SizedBox(height: 14),
                              _ExecutiveControlError(
                                onRetry: _refresh,
                                errorText: snapshot.error.toString(),
                              ),
                            ],
                          );
                        }

                        if (waiting && metrics == null) {
                          return Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              header,
                              const SizedBox(height: 14),
                              const _ExecutiveControlSkeleton(),
                            ],
                          );
                        }

                        final m = metrics ?? ExecutiveControlMetrics.empty();

                        // ✅ Null-safe, non-null list for UI (even if upstream changes later)
                        final List<ExecutivePriorityItem> top3 =
                            m.topPriorities.whereType<ExecutivePriorityItem>().toList();

                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            header,
                            const SizedBox(height: 14),

                            // 2) Factory Health Score Card
                            _FactoryHealthScoreCard(metrics: m),
                            const SizedBox(height: 14),

                            // 3) Top 3 Priorities
                            _TopPrioritiesList(
                              items: top3,
                              onOpen: (batchId) {
                                context.push(
                                  "${AppRouter.KManagerBatchDetailsView}/$batchId",
                                );
                              },
                            ),
                            const SizedBox(height: 14),

                            // 4) Decisions Waiting Card
                            _DecisionsWaitingCard(
                              decisionsWaiting: m.decisionsWaiting,
                              onReviewInbox: () {
                                context.read<ManagerNavCubit>().changeTab(1);
                              },
                            ),
                            const SizedBox(height: 14),

                            // 5) Mini Snapshot Chips (ONLY 3)
                            _MiniSnapshotChips(
                              pendingQc: m.pendingQc,
                              blocked: m.blocked,
                              readyToShip: m.readyToShip,
                            ),

                            const SizedBox(height: 80),
                          ],
                        );
                      },
                    ),
                  ],
                ),
              ),
            ),
          );
        }

        return const SizedBox();
      },
    );
  }

  ExecutiveStatusBadge _statusBadgeFrom(ExecutiveControlMetrics m) {
    final isCritical = m.slaCritical > 0 || m.failedWithoutDecision > 0;
    if (isCritical) return ExecutiveStatusBadge.critical;

    final isAttention =
        m.slaWarning > 0 || m.evidenceMissing > 0 || m.highRiskUnresolved > 0;
    if (isAttention) return ExecutiveStatusBadge.attention;

    return ExecutiveStatusBadge.stable;
  }
}

enum ExecutiveStatusBadge { stable, attention, critical }

class _ExecutiveHeader extends StatelessWidget {
  final String managerName;
  final String role;
  final DateTime date;
  final VoidCallback onRefresh;
  final ExecutiveStatusBadge? badge;

  const _ExecutiveHeader({
    required this.managerName,
    required this.role,
    required this.date,
    required this.onRefresh,
    required this.badge,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Hello, $managerName",
                style: theme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w800,
                  letterSpacing: 0.1,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                role,
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: Colors.black54,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                DateFormatter.formatDate(date),
                style: theme.textTheme.bodySmall?.copyWith(
                  color: Colors.black45,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 10),
              if (badge != null) _StatusPill(badge: badge!),
            ],
          ),
        ),
        IconButton(
          onPressed: onRefresh,
          icon: const Icon(Icons.refresh_rounded),
          tooltip: 'Refresh',
        ),
      ],
    );
  }
}

class _StatusPill extends StatelessWidget {
  final ExecutiveStatusBadge badge;

  const _StatusPill({required this.badge});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    String label;
    Color bg;
    Color fg;

    switch (badge) {
      case ExecutiveStatusBadge.stable:
        label = 'Stable';
        bg = const Color(0xFFE8F5E9);
        fg = const Color(0xFF1B5E20);
        break;
      case ExecutiveStatusBadge.attention:
        label = 'Attention';
        bg = const Color(0xFFFFF8E1);
        fg = const Color(0xFF8D6E00);
        break;
      case ExecutiveStatusBadge.critical:
        label = 'Critical';
        bg = const Color(0xFFFFEBEE);
        fg = const Color(0xFFB71C1C);
        break;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: bg.withOpacity(0.65)),
      ),
      child: Text(
        label,
        style: theme.textTheme.labelLarge?.copyWith(
          color: fg,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }
}

class _FactoryHealthScoreCard extends StatelessWidget {
  final ExecutiveControlMetrics metrics;

  const _FactoryHealthScoreCard({required this.metrics});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    final score = metrics.healthScore;
    final reasons = metrics.topWhyReasons;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 16,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                "$score",
                style: theme.textTheme.displaySmall?.copyWith(
                  fontWeight: FontWeight.w900,
                  height: 1.0,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  "Health Score",
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            "Based on open issues: SLA, pending decisions, blocked, evidence, risk",
            style: theme.textTheme.bodySmall?.copyWith(
              color: Colors.black54,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 12),
          ...reasons.map(
            (r) => Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Row(
                children: [
                  const Icon(Icons.circle, size: 7, color: Colors.black54),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      r,
                      style: theme.textTheme.bodyMedium?.copyWith(
                        fontWeight: FontWeight.w700,
                        color: Colors.black87,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _TopPrioritiesList extends StatelessWidget {
  final List<ExecutivePriorityItem> items;
  final void Function(String batchId) onOpen;

  const _TopPrioritiesList({required this.items, required this.onOpen});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Top 3 Priorities',
          style: theme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w900,
          ),
        ),
        const SizedBox(height: 8),
        if (items.isEmpty)
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: Colors.grey.shade200),
            ),
            child: Text(
              'No urgent priorities right now.',
              style: theme.textTheme.bodyMedium?.copyWith(
                color: Colors.black54,
                fontWeight: FontWeight.w600,
              ),
            ),
          )
        else
          ListView.builder(
            itemCount: items.length,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemBuilder: (context, index) {
              final p = items[index]; // ✅ non-null local
              return Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: Colors.grey.shade200),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.03),
                        blurRadius: 10,
                        offset: const Offset(0, 5),
                      ),
                    ],
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              p.title,
                              style: theme.textTheme.bodyLarge?.copyWith(
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              p.reason,
                              style: theme.textTheme.bodyMedium?.copyWith(
                                color: Colors.black54,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              p.timeLabel,
                              style: theme.textTheme.labelLarge?.copyWith(
                                color: Colors.black87,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 10),
                      SizedBox(
                        height: 44,
                        child: ElevatedButton(
                          onPressed: () => onOpen(p.batchId),
                          child: const Text('Open'),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
      ],
    );
  }
}

class _DecisionsWaitingCard extends StatelessWidget {
  final int decisionsWaiting;
  final VoidCallback onReviewInbox;

  const _DecisionsWaitingCard({
    required this.decisionsWaiting,
    required this.onReviewInbox,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Decisions waiting',
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: Colors.black54,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '$decisionsWaiting',
                  style: theme.textTheme.headlineMedium?.copyWith(
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ],
            ),
          ),
          SizedBox(
            height: 46,
            child: ElevatedButton(
              onPressed: onReviewInbox,
              child: const Text('Review Inbox'),
            ),
          ),
        ],
      ),
    );
  }
}

class _MiniSnapshotChips extends StatelessWidget {
  final int pendingQc;
  final int blocked;
  final int readyToShip;

  const _MiniSnapshotChips({
    required this.pendingQc,
    required this.blocked,
    required this.readyToShip,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Wrap(
      spacing: 10,
      runSpacing: 10,
      children: [
        _Chip(title: 'Pending QC', value: pendingQc, theme: theme),
        _Chip(title: 'Blocked', value: blocked, theme: theme),
        _Chip(title: 'Ready to ship', value: readyToShip, theme: theme),
      ],
    );
  }
}

class _Chip extends StatelessWidget {
  final String title;
  final int value;
  final ThemeData theme;

  const _Chip({
    required this.title,
    required this.value,
    required this.theme,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            title,
            style: theme.textTheme.bodyMedium?.copyWith(
              color: Colors.black54,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(width: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: const Color(0xFFF7F9FC),
              borderRadius: BorderRadius.circular(999),
              border: Border.all(color: Colors.grey.shade200),
            ),
            child: Text(
              '$value',
              style: theme.textTheme.labelLarge?.copyWith(
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ExecutiveControlLoading extends StatelessWidget {
  final VoidCallback onRefresh;

  const _ExecutiveControlLoading({required this.onRefresh});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F9FC),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Container(
                      height: 62,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(14),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  IconButton(
                    onPressed: onRefresh,
                    icon: const Icon(Icons.refresh_rounded),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              const _ExecutiveControlSkeleton(),
            ],
          ),
        ),
      ),
    );
  }
}

class _ExecutiveControlSkeleton extends StatelessWidget {
  const _ExecutiveControlSkeleton();

  @override
  Widget build(BuildContext context) {
    Widget box(double h) => Container(
          height: h,
          width: double.infinity,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
          ),
        );

    return Column(
      children: [
        box(160),
        const SizedBox(height: 14),
        box(220),
        const SizedBox(height: 14),
        box(96),
        const SizedBox(height: 14),
        box(52),
      ],
    );
  }
}

class _ExecutiveControlError extends StatelessWidget {
  final VoidCallback onRetry;
  final String errorText;

  const _ExecutiveControlError({required this.onRetry, required this.errorText});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Failed to load dashboard data',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            errorText,
            style: theme.textTheme.bodySmall?.copyWith(color: Colors.black54),
            maxLines: 3,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 44,
            child: ElevatedButton(
              onPressed: onRetry,
              child: const Text('Retry'),
            ),
          ),
        ],
      ),
    );
  }
}
