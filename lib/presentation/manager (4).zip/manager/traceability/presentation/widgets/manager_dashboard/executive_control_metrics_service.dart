import 'package:alwadi_food/core/constants/app_constants.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class ExecutiveControlMetricsService {
  final FirebaseFirestore _firestore;

  ExecutiveControlMetricsService({FirebaseFirestore? firestore})
      : _firestore = firestore ?? FirebaseFirestore.instance;

  Future<ExecutiveControlMetrics> fetch() async {
    final now = DateTime.now();

    // 1) waiting_qc -> SLA warning/critical
    final waitingQcSnap = await _firestore
        .collection(AppConstants.batchesCollection)
        .where('status', isEqualTo: AppConstants.statusWaitingQC)
        .get();

    int slaWarning = 0;
    int slaCritical = 0;
    final slaCriticalItems = <ExecutivePriorityItem>[];

    for (final doc in waitingQcSnap.docs) {
      final data = doc.data();
      final updatedAt = _readDate(data['updatedAt']) ?? _readDate(data['startTime']);
      if (updatedAt == null) continue;

      final waiting = now.difference(updatedAt);
      final hours = waiting.inHours;

      if (hours >= 12) {
        slaCritical++;
        slaCriticalItems.add(
          ExecutivePriorityItem(
            batchId: doc.id,
            severityRank: 1,
            waiting: waiting,
            title: 'Batch ${_shortId(doc.id)} waiting QC',
            reason: 'SLA critical — waiting_qc ≥ 12h',
          ),
        );
      } else if (hours >= 6) {
        slaWarning++;
      }
    }

    // 2) Decisions waiting (passed/failed + no managerDecisionStatus)
    final decisionsSnap = await _firestore
        .collection(AppConstants.batchesCollection)
        .where('status', whereIn: [AppConstants.statusPassed, AppConstants.statusFailed])
        .where('managerDecisionStatus', isNull: true)
        .get();

    final decisionsWaiting = decisionsSnap.size;

    int failedWithoutDecision = 0;
    final failedNoDecisionItems = <ExecutivePriorityItem>[];

    for (final doc in decisionsSnap.docs) {
      final data = doc.data();
      final status = (data['status'] ?? '').toString();
      final updatedAt = _readDate(data['updatedAt']) ?? _readDate(data['startTime']);
      final waiting = updatedAt == null ? Duration.zero : now.difference(updatedAt);

      if (status == AppConstants.statusFailed) {
        failedWithoutDecision++;
        failedNoDecisionItems.add(
          ExecutivePriorityItem(
            batchId: doc.id,
            severityRank: 2,
            waiting: waiting,
            title: 'Batch ${_shortId(doc.id)} needs decision',
            reason: 'QC failed — waiting manager decision',
          ),
        );
      }
    }

    // 3) QC failed evidence missing + High risk unresolved
    final since = now.subtract(const Duration(days: 30));
    final qcSnap = await _firestore
        .collection(AppConstants.qcResultsCollection)
        .where('createdAt', isGreaterThanOrEqualTo: Timestamp.fromDate(since))
        .get();

    int evidenceMissing = 0;
    final evidenceMissingItems = <ExecutivePriorityItem>[];

    int highRiskUnresolved = 0;
    final highRiskItems = <ExecutivePriorityItem>[];

    for (final doc in qcSnap.docs) {
      final data = doc.data();
      final result = (data['result'] ?? data['qcResult'] ?? '').toString();
      final batchId = (data['batchId'] ?? '').toString();
      if (batchId.trim().isEmpty) continue;

      final createdAt = _readDate(data['createdAt']) ?? now;
      final waiting = now.difference(createdAt);

      // Evidence Missing: QC failed but no images OR no failure reason.
      if (result == AppConstants.qcResultFail) {
        final imagesRaw = data['images'];
        final images = (imagesRaw is List)
            ? imagesRaw.whereType<String>().toList()
            : <String>[];
        final reason = (data['failureReason'] ?? '').toString().trim();

        final missing = images.isEmpty || reason.isEmpty;
        if (missing) {
          evidenceMissing++;
          evidenceMissingItems.add(
            ExecutivePriorityItem(
              batchId: batchId,
              severityRank: 3,
              waiting: waiting,
              title: 'Batch ${_shortId(batchId)} missing evidence',
              reason: 'QC failed — evidence or reason missing',
            ),
          );
        }
      }

      // High Risk unresolved (if already computed in qc_results)
      final resolved = data['riskResolved'];
      final isResolved = resolved is bool && resolved == true;
      if (!isResolved) {
        final temp = _readNum(data['temperature']);
        final moisture = _readNum(data['moisture']);
        final isHighRisk = temp > 10 || moisture > 15;
        if (isHighRisk) {
          highRiskUnresolved++;
          highRiskItems.add(
            ExecutivePriorityItem(
              batchId: batchId,
              severityRank: 4,
              waiting: waiting,
              title: 'Batch ${_shortId(batchId)} high risk',
              reason: 'High risk — unresolved QC measurement',
            ),
          );
        }
      }
    }

    // 4) Snapshot chips
    final pendingQc = waitingQcSnap.size;

    final blockedByDecisionSnap = await _firestore
        .collection(AppConstants.batchesCollection)
        .where('managerDecisionStatus', whereIn: ['hold', 'rejected'])
        .get();

    final failedBatchesSnap = await _firestore
        .collection(AppConstants.batchesCollection)
        .where('status', isEqualTo: AppConstants.statusFailed)
        .get();

    final blockedIds = <String>{};
    for (final d in blockedByDecisionSnap.docs) {
      blockedIds.add(d.id);
    }
    for (final d in failedBatchesSnap.docs) {
      blockedIds.add(d.id);
    }
    final blocked = blockedIds.length;

    final readySnap = await _firestore
        .collection(AppConstants.batchesCollection)
        .where('status', isEqualTo: AppConstants.statusPassed)
        .where('managerDecisionStatus', isEqualTo: 'approved')
        .get();
    final readyToShip = readySnap.size;

    // Health score (0–100)
    int score = 100;
    score -= 10 * slaCritical;
    score -= 5 * slaWarning;
    score -= 8 * failedWithoutDecision;
    score -= 6 * evidenceMissing;
    score -= 3 * highRiskUnresolved;
    if (score < 0) score = 0;
    if (score > 100) score = 100;

    // Top 3 priorities (severity then longest waiting)
    final allPriority = <ExecutivePriorityItem>[
      ...slaCriticalItems,
      ...failedNoDecisionItems,
      ...evidenceMissingItems,
      ...highRiskItems,
    ];

    allPriority.sort((a, b) {
      final s = a.severityRank.compareTo(b.severityRank);
      if (s != 0) return s;
      return b.waiting.compareTo(a.waiting);
    });

    final topPriorities = allPriority.take(3).map((e) => e.withTimeLabel()).toList();

    // WHY reasons (3 bullets)
    final whyPairs = <MapEntry<String, int>>[
      MapEntry('Decisions waiting', decisionsWaiting),
      MapEntry('SLA critical', slaCritical),
      MapEntry('Blocked batches', blocked),
      MapEntry('Evidence missing', evidenceMissing),
      MapEntry('High risk unresolved', highRiskUnresolved),
      MapEntry('SLA warning', slaWarning),
    ];

    final why = <String>[];
    for (final p in whyPairs) {
      if (p.value <= 0) continue;
      why.add('${p.key}: ${p.value}');
      if (why.length == 3) break;
    }
    while (why.length < 3) {
      why.add('No critical issues detected');
      if (why.length == 3) break;
    }

    return ExecutiveControlMetrics(
      slaWarning: slaWarning,
      slaCritical: slaCritical,
      decisionsWaiting: decisionsWaiting,
      failedWithoutDecision: failedWithoutDecision,
      evidenceMissing: evidenceMissing,
      highRiskUnresolved: highRiskUnresolved,
      pendingQc: pendingQc,
      blocked: blocked,
      readyToShip: readyToShip,
      healthScore: score,
      topWhyReasons: why,
      topPriorities: topPriorities,
    );
  }

  static DateTime? _readDate(dynamic v) {
    if (v is Timestamp) return v.toDate();
    if (v is DateTime) return v;
    return null;
  }

  static double _readNum(dynamic v) {
    if (v is num) return v.toDouble();
    if (v is String) return double.tryParse(v) ?? 0;
    return 0;
  }

  static String _shortId(String id) {
    if (id.length <= 6) return id;
    return id.substring(0, 6);
  }
}

class ExecutiveControlMetrics {
  final int slaWarning;
  final int slaCritical;
  final int decisionsWaiting;
  final int failedWithoutDecision;
  final int evidenceMissing;
  final int highRiskUnresolved;

  final int pendingQc;
  final int blocked;
  final int readyToShip;

  final int healthScore;
  final List<String> topWhyReasons;

  /// ✅ Non-nullable list (fix)
  final List<ExecutivePriorityItem> topPriorities;

  const ExecutiveControlMetrics({
    required this.slaWarning,
    required this.slaCritical,
    required this.decisionsWaiting,
    required this.failedWithoutDecision,
    required this.evidenceMissing,
    required this.highRiskUnresolved,
    required this.pendingQc,
    required this.blocked,
    required this.readyToShip,
    required this.healthScore,
    required this.topWhyReasons,
    required this.topPriorities,
  });

  static ExecutiveControlMetrics empty() {
    return const ExecutiveControlMetrics(
      slaWarning: 0,
      slaCritical: 0,
      decisionsWaiting: 0,
      failedWithoutDecision: 0,
      evidenceMissing: 0,
      highRiskUnresolved: 0,
      pendingQc: 0,
      blocked: 0,
      readyToShip: 0,
      healthScore: 100,
      topWhyReasons: [
        'No critical issues detected',
        'No critical issues detected',
        'No critical issues detected',
      ],
      topPriorities: <ExecutivePriorityItem>[],
    );
  }
}

class ExecutivePriorityItem {
  final String batchId;
  final int severityRank;
  final Duration waiting;
  final String title;
  final String reason;
  final String timeLabel;

  const ExecutivePriorityItem({
    required this.batchId,
    required this.severityRank,
    required this.waiting,
    required this.title,
    required this.reason,
    this.timeLabel = '',
  });

  ExecutivePriorityItem withTimeLabel() {
    final h = waiting.inHours;
    final m = waiting.inMinutes;

    String label;
    if (h >= 24) {
      final d = (h / 24).floor();
      label = 'Waiting ${d}d';
    } else if (h >= 1) {
      label = 'Waiting ${h}h';
    } else {
      label = 'Waiting ${m}m';
    }

    return ExecutivePriorityItem(
      batchId: batchId,
      severityRank: severityRank,
      waiting: waiting,
      title: title,
      reason: reason,
      timeLabel: label,
    );
  }
}
