import 'package:alwadi_food/core/di/injection.dart';
import 'package:alwadi_food/presentation/manager/cubit/manager_nav/manager_nav_cubit.dart';
import 'package:alwadi_food/presentation/manager/cubit/manager_nav/manager_nav_state.dart';
import 'package:alwadi_food/presentation/manager/presentation/views/manager_dashboard_view.dart';
import 'package:alwadi_food/presentation/manager/presentation/views/widgets/manager_action/manager_action_needed_view.dart';
import 'package:alwadi_food/presentation/manager/presentation/views/widgets/reports/reports_center_view.dart';
import 'package:alwadi_food/presentation/manager/traceability/cubit/traceability_cubit.dart';
import 'package:alwadi_food/presentation/manager/traceability/presentation/screens/traceability_center_screen.dart';
import 'package:alwadi_food/presentation/manager/traceability_v3/presentation/views/traceability_view.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class ManagerMainViewBodyBlocConsumer extends StatefulWidget {
  final ThemeData theme;
  const ManagerMainViewBodyBlocConsumer({super.key, required this.theme});

  @override
  State<ManagerMainViewBodyBlocConsumer> createState() =>
      _ManagerMainViewBodyBlocConsumerState();
}

class _ManagerMainViewBodyBlocConsumerState
    extends State<ManagerMainViewBodyBlocConsumer> {
  // ✅ Important: keep pages as fields so they are not recreated every build
  late final List<Widget> _pages;

  @override
  void initState() {
    super.initState();
    _pages = [
      ManagerDashboardView(), // Tab 0
      ManagerActionNeededView(), // Tab 1
      ReportsCenterView(), // Tab 2
      TraceabilityView(rootNodeId: ''),//Tab 3
      _PlaceholderPage(title: "More (Users/Performance)"), // Tab 4
    ];
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ManagerNavCubit, ManagerNavState>(
      builder: (context, state) {
        return Scaffold(
          // ✅ This keeps pages alive and prevents dispose/recreate
          body: IndexedStack(index: state.index, children: _pages),
          bottomNavigationBar: Container(
            decoration: BoxDecoration(
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.06),
                  blurRadius: 12,
                  offset: const Offset(0, -4),
                ),
              ],
            ),
            child: BottomNavigationBar(
              currentIndex: state.index,
              onTap: (i) => context.read<ManagerNavCubit>().changeTab(i),
              type: BottomNavigationBarType.fixed,
              selectedItemColor: widget.theme.colorScheme.primary,
              unselectedItemColor: Colors.grey,
              items: const [
                BottomNavigationBarItem(
                  icon: Icon(Icons.dashboard_rounded),
                  label: "Dashboard",
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.task_alt_rounded),
                  label: "Action Needed",
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.picture_as_pdf_rounded),
                  label: "Reports",
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.track_changes_rounded),
                  label: "Trace",
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.more_horiz_rounded),
                  label: "More",
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

/// مؤقتة لحد ما نبني صفحات Reports/Traceability
class _PlaceholderPage extends StatelessWidget {
  final String title;
  const _PlaceholderPage({required this.title});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Center(
        child: Text(
          title,
          style: Theme.of(
            context,
          ).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}
