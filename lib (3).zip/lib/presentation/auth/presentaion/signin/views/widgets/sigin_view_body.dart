import 'dart:ui' as ui;
import 'package:alwadi_food/core/router/app_router.dart';
import 'package:alwadi_food/core/utils/validators.dart';
import 'package:alwadi_food/presentation/auth/cubit/auth_cubit.dart';
import 'package:alwadi_food/presentation/splash/presntation/views/widgets/splash_view_body.dart';
import 'package:alwadi_food/presentation/widgets/custom_button.dart';
import 'package:alwadi_food/presentation/widgets/custom_text_field.dart';
import 'package:alwadi_food/theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';

class SigninViewBody extends StatefulWidget {
  const SigninViewBody({super.key});

  @override
  State<SigninViewBody> createState() => _SigninViewBodyState();
}

class _SigninViewBodyState extends State<SigninViewBody> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  AutovalidateMode autovalidateMode = AutovalidateMode.disabled;
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  bool _obscure = true;

  void _handleLogin() {
    if (_formKey.currentState!.validate()) {
      final email = _emailController.text.trim();
      final password = _passwordController.text;
      if (email.isEmpty || password.isEmpty) return;

      context.read<AuthCubit>().signIn(email: email, password: password);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: AppSpacing.paddingLg,
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 60),

                // 👇 الأيقونة الآن Animated + في المنتصف + بطيئة نسبياً
                const Center(child: LoginFallingAlwadiIcon()),

                const SizedBox(height: 24),
                Center(
                  child: Text(
                    'Welcome Back',
                    style: theme.textTheme.headlineMedium?.bold,
                  ),
                ),
                const SizedBox(height: 8),
                Center(
                  child: Text(
                    'Sign in to continue',
                    style: theme.textTheme.bodyLarge?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                ),
                const SizedBox(height: 48),

                CustomTextField(
                  suffixIcon: Icon(
                    Icons.email,
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                  controller: _emailController,
                  label: 'Email',
                  hint: 'Enter your email',
                  validator: Validators.validateEmail,
                  keyboardType: TextInputType.emailAddress,
                ),
                const SizedBox(height: AppSpacing.lg),

                CustomTextField(
                  controller: _passwordController,
                  label: 'Password',
                  hint: 'Enter your password',
                  validator: Validators.validatePassword,
                  obscureText: _obscure,
                  suffixIcon: IconButton(
                    icon: Icon(
                      _obscure ? Icons.visibility_off : Icons.visibility,
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                    onPressed: () => setState(() {
                      _obscure = !_obscure;
                    }),
                  ),
                ),

                const SizedBox(height: 32),

                CustomButton(
                  text: 'Sign In',
                  onPressed: _handleLogin,
                  icon: Icons.login,
                ),

                TextButton(
                  onPressed: () => context.push(AppRouter.KSignup),
                  child: const Text("Create a new account"),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// =====================
///  Login Falling Icon
/// =====================
/// أول ما تفتح صفحة اللوجن:
/// - الأيقونة تبدأ من أعلى الشاشة (خارج الفيو)
/// - تنزل ببطء لمدة 700ms إلى مكانها النهائي
/// - نفس الـ curve: easeInOutCubic عشان الإحساس يكون ناعم و Executive.
class LoginFallingAlwadiIcon extends StatefulWidget {
  const LoginFallingAlwadiIcon({super.key});

  @override
  State<LoginFallingAlwadiIcon> createState() => _LoginFallingAlwadiIconState();
}

class _LoginFallingAlwadiIconState extends State<LoginFallingAlwadiIcon>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  static const int _durationMs = 700; // أبطأ من قبل عشان العميل يستمتع

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: _durationMs),
    );

    // نبدأ الأنيميشن بعد أول فريم عشان كل عناصر الصفحة تكون جاهزة
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        _controller.forward();
      }
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.sizeOf(context);

    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) {
        final double progress = Curves.easeInOutCubic.transform(
          _controller.value,
        );

        // من أعلى الشاشة (−0.4 من الارتفاع) → 0 (الموضع النهائي)
        final double offsetY =
            ui.lerpDouble(-size.height * 0.4, 0.0, progress) ?? 0.0;

        return Transform.translate(
          offset: Offset(0, offsetY),
          child: const AlwadiIcon(), // نفس الأيقونة المستخدمة في Splash
        );
      },
    );
  }
}
